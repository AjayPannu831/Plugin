<?php

/**
 * Plugin Name: Slider-Image
 * Description: This is a demo of the slider that shows how to make a plugin and its use.
 * Version: 1
 * Require PHP: 7.0
 * Author: Ajay Pannu
 * Author URI: https://ajaypannu003.000webhostapp.com
 */

if (!defined('ABSPATH')) {
    exit;
}
// include './function/enqueue_plugin_scripts.php';
include_once plugin_dir_path(__FILE__) . './functions/wp_enqueue/enqueue_plugin_scripts.php';

add_action('wp_enqueue_scripts', 'enqueue_plugin_scripts');

// Enqueue script to handle media library integration
include_once plugin_dir_path(__FILE__) .'./functions/wp_enqueue/enqueue_media_script.php';

add_action('admin_enqueue_scripts', 'enqueue_media_script');

// Activation hook to create the database table
register_activation_hook(__FILE__, 'slider_image_create_table');

// Deactivation hook to drop the database table
// register_deactivation_hook(__FILE__, 'slider_image_drop_table');

// Callback function to create the database table
include_once plugin_dir_path(__FILE__) ."./functions/database/Create_table.php";

// Callback function to drop the database table on deactivation
include_once plugin_dir_path(__FILE__) ."./functions/database/drop_table.php";

// Add menu item to the dashboard
add_action('admin_menu', 'slider_image_menu');

// Callback function for the menu page
include_once plugin_dir_path(__FILE__) .'./functions/menu_page.php';

// Callback function to display the page content
include_once plugin_dir_path(__FILE__) . './functions/create_slider_page.php';


// Add this action to handle slider deletion
include_once plugin_dir_path(__FILE__) .'./functions/database/delete_slider.php';

add_action('wp_ajax_delete_slider', 'delete_slider_callback');

// function generate_slider_html($slider_id)
include_once plugin_dir_path(__FILE__) .'./functions/Slider/generate_slider.php';

// Register the shortcode
add_shortcode('slider', 'slider_shortcode');

include_once plugin_dir_path(__FILE__) .'./functions/Slider/slider_shortcode.php';

// function get_slider_data($slider_id)
include_once plugin_dir_path(__FILE__) .'./functions/database/Get_slider_data.php';

// Callback function for the edit slider page
include_once plugin_dir_path(__FILE__) .'./functions/edit_slider_page.php';

// add_action for delete images
add_action('wp_ajax_handle_deleted_images', 'handle_deleted_images_callback');

// Function of deleted image from slider
include_once plugin_dir_path(__FILE__) .'./functions/Slider/delete_images.php';

// Function to update slider data in the database
include_once plugin_dir_path( __FILE__ ) .'./functions/Slider/update_slider_data.php';
    


