<?php

function handle_deleted_images_callback()
{
    check_ajax_referer('handle_deleted_images_nonce', 'security');
    $slider_id = absint($_POST['slider_id']);

    if (isset($_POST['image_urls']) && is_array($_POST['image_urls']) && ($slider_id == $_GET['id'])) {
        $image_urls = array_map('sanitize_text_field', $_POST['image_urls']);

        global $wpdb;
        $table_name = $wpdb->prefix . 'slider_images';


        // if(isset($_POST['slider_id']) ){
        foreach ($image_urls as $image_url) {
            // Fetch existing image URLs
            $existing_image_urls = $wpdb->get_var($wpdb->prepare("SELECT image FROM $table_name WHERE image LIKE %s", '%' . $image_url . '%'));

            // Fetch existing image URLs as an array
            $existing_image_urls_array = explode(',', $existing_image_urls);

            // Remove the image URL from the array
            $existing_image_urls_array = array_diff($existing_image_urls_array, array($image_url));

            // Combine existing image URLs back into a string
            $updated_image_urls = implode(',', array_filter($existing_image_urls_array));

            // Update the database with the new image URLs
            $result = $wpdb->query(
                $wpdb->prepare("UPDATE $table_name SET image = %s WHERE image LIKE %s", $updated_image_urls, '%' . $image_url . '%')
            );

            if ($result === false) {
                // Check for errors in the update operation
                $wpdb_last_error = $wpdb->last_error;
                error_log('Error updating image: ' . $wpdb_last_error);
                error_log('Last query: ' . $wpdb->last_query);
            }
            // }
        }

        $response = array(
            'status' => 'success',
            'deleted_images' => $image_urls,
        );

        echo json_encode($response);
    } else {
        $response = array(
            'status' => 'error',
            'message' => 'Invalid data received.',
        );

        echo json_encode($response);
    }

    wp_die();
}
