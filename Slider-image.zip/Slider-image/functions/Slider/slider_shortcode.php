<?php
function slider_shortcode($atts)
{
    // Extract shortcode attributes
    $atts = shortcode_atts(
        array(
            'id' => '', // Default value for the slider ID
        ),
        $atts,
        'slider'
    );

    // Fetch slider data
    $slider_data = get_slider_data($atts['id']);

    // Generate slider HTML based on the provided ID
    $slider_html = generate_slider_html($atts['id']);

    // Output the slider HTML
    echo $slider_html;

    // Output the JavaScript script with dynamic values
?>
    <script>
        jQuery(document).ready(function($) {
            // Initialize slick slider
            $('.slick-slider').slick({
                slidesToShow: <?php echo esc_attr($slider_data['slider-show']); ?>,
                slidesToScroll: <?php echo esc_attr($slider_data['slider-scroll']); ?>,
                infinite: true,
                dots: true,
                arrows: true,
                prevArrow: '<button type="button" class="slick-prev"></button>',
                nextArrow: '<button type="button" class="slick-next"></button>',
                // margin: 20,
                // padding: 20,
                autoplay: true,
                autoplaySpeed: 1500,
                fade: <?php echo ($slider_data['animation_type'] == 'true') ? 'true' : 'false'; ?>,
            });
        });
    </script>
    <style>
        .slick-slider {
            height: <?php echo esc_attr($slider_data['Height_slider']); ?>px;
            width: 100%;
            overflow: hidden;
        }

        .slider-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .image-container {
            max-height: 100%;
            max-width: 100%;
            overflow: hidden;
            object-fit: cover;
            margin: 10px;
        }
        
        .slick-prev,
        .slick-next {
            font-size: 24px;
            line-height: 1;
            color: #fff;
            padding: 10px;
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            z-index: 1;
            
        }
        .slick-prev {
            left: 10px;
        }

        .slick-next {
            right: 25px;
        }
    </style>
<?php
}
?>