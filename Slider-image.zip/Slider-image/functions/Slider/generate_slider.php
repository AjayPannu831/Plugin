<?php
function generate_slider_html($slider_id)
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'slider_images';

    // Fetch slider images based on the provided ID
    $slider_images = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE id = %s", $slider_id), ARRAY_A);

    if (!empty($slider_images)) {

        $slider_html = '<div class="container slick-slider">';
        foreach ($slider_images as $slider_image) {
            $images = explode(',', $slider_image['image']);
            foreach ($images as $image_url) {
                $slider_html .= '<div class="image-container"><img src="' . esc_url($image_url) . '" alt="Slider Image" class="slider-image"></div>';
            }
        }
        $slider_html .= '</div>';
        ?>
        <style>
                
            </style>
            <?php

        return $slider_html;
    }
    return '';
}
?>
