<?php
function update_slider_data($slider_id, $slider_name, $new_image_ids, $slides_to_show, $slides_to_scroll,$slider_height)
{
    global $wpdb;

    // Define the table name
    $table_name = $wpdb->prefix . 'slider_images';

    // Fetch existing image URLs
    $existing_image_urls = $wpdb->get_var($wpdb->prepare("SELECT image FROM $table_name WHERE id = %d", $slider_id));

    // Fetch new image URLs based on new image IDs
    $new_image_urls = array_map('wp_get_attachment_url', $new_image_ids);

    // Combine existing and new image URLs
    $all_image_urls = implode(',', array_filter(array_merge(explode(',', $existing_image_urls), $new_image_urls)));
    // Update slider data in the database
    $updated_animation_type = sanitize_text_field($_POST['animation_type']);

 
    // Update slider name, images, slide-show, and slide-scroll
    $result = $wpdb->update(
        $table_name,
        array(
            'slider' => $slider_name,
            'image' => $all_image_urls,
            'slider-show' => $slides_to_show,
            'slider-scroll' => $slides_to_scroll,
            'animation_type' => $updated_animation_type,
            'Height_slider' => $slider_height,
        ),
        array('id' => $slider_id),
        array('%s', '%s', '%d', '%d', '%s', '%d'), // Data Format for slider name, image, slide-show, slide-scroll, animation_type, and height
        array('%d')                                  // Where Format
    );

    if ($result !== false) {
        // Success: Update existing image URLs in the database
        $updated_existing_image_urls = $wpdb->update(
            $table_name,
            array('image' => $all_image_urls),
            array('id' => $slider_id),
            array('%s'),
            array('%d')
        );

        if ($updated_existing_image_urls !== false) {
            echo '<div class="updated"><p class="text-success">Slider updated successfully!</p></div>';
        } else {
            echo '<p class="text-danger">Failed to update existing image URLs.</p>';
        }
    } else {
        echo '<p class="text-danger">Failed to update slider.</p>';
    }
}
