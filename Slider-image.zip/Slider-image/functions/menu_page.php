<?php
function slider_image_menu()
{
    add_menu_page(
        'Slider Image Settings',
        'Slider Image',
        'manage_options',
        'slider_image_settings',
        'slider_image_page'
    );
    add_submenu_page(
        'slider_image_settings',
        'Edit Slider',
        'Edit Slider',
        'manage_options',
        'edit_slider',
        'edit_slider_page'
    );
}