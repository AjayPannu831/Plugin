<?php
function enqueue_plugin_scripts()
{
    // Bootstrap cdn link
    wp_enqueue_style('Bootstrap-style', 'https://maxcdn.bootstrapcdn.com/bootstrap/5.3.2/css/bootstrap.min.css');
    wp_enqueue_script('Bootstrap-js', 'https://maxcdn.bootstrapcdn.com/bootstrap/5.3.2/js/bootstrap.bundle.min.js', array('jquery'), '5.3.2', true);

    // Add FontAwesome CDN link in your plugin file or include it through your theme
    wp_enqueue_script('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js', array(), '5.15.1', false);



    // Enqueue Slick slider CSS
    wp_enqueue_style('slick-style', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css');
    wp_enqueue_style('slick-theme-style', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css');

    // Enqueue Slick slider JS
    wp_enqueue_script('slick-script', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js', array('jquery'), '1.8.1', true);

    // Enqueue your initialization script
    // wp_enqueue_script('slick-init', plugins_url('your-script.js', __FILE__), array('jquery', 'slick-script'), '1.0', true);
}

// add_action('wp_enqueue_scripts', 'enqueue_plugin_scripts');
?>