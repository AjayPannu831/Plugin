<?php
function enqueue_media_script()
{
    wp_enqueue_media();
    // wp_enqueue_script('slider-image-script', plugins_url('../js/script.js', __FILE__), array('jquery'), null, true);
    
    // wp_enqueue_script('slider-delete-script', plugins_url('../js/delete_slider.js', __FILE__), array('jquery'), null, true);
     // Enqueue Lightbox CSS and JS
     wp_enqueue_style('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css', array(), null, 'all');
     wp_enqueue_script('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js', array('jquery'), null, true);

     // Enqueue Slick slider CSS and JS
     wp_enqueue_style('slick-carousel', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css', array(), null, 'all');
     wp_enqueue_style('slick-carousel-theme', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css', array(), null, 'all');
     wp_enqueue_script('slick-carousel', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js', array('jquery'), null, true);
    
}