<?php
function slider_image_page()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'slider_images';

    // Check if the form is submitted
    if (isset($_POST['submit_slider']) && isset($_POST['slider_name'])) {
        // Check if any image is selected
        if (isset($_POST['selected_attachment_ids']) && !empty($_POST['selected_attachment_ids'])) {
            // Verify nonce
            if (isset($_POST['save_slider_nonce']) && wp_verify_nonce($_POST['save_slider_nonce'], 'save_slider')) {
                $slider_name = sanitize_text_field($_POST['slider_name']);
                $attachment_ids = array_map('absint', $_POST['selected_attachment_ids']);
                $image_names = array();

                // Insert data into the table
                foreach ($attachment_ids as $attachment_id) {
                    $image_names[] = wp_get_attachment_url($attachment_id);
                }

                $result = $wpdb->insert(
                    $table_name,
                    array(
                        'slider' => $slider_name,
                        'image' => implode(',', $image_names),
                    )
                );
                if ($result == true) {
                    // Display success message
                    echo '<div class="updated"><p>Slider created successfully!</p></div>';
                } else {
                    // Display error message if the insert failed
                    echo '<div class="error"><p>Error creating slider. Please try again.</p></div>';
                }
            }
        } else {
            echo '<div class="error"><p>Error creating slider. Please select image at least 1.</p></div>';
        }
    }

    // Fetch all sliders from the database
    $sliders = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);
?>

    <div class="wrap container">
        <div class="container">
            <h2>Create Slider</h2>
            <form method="post" action="" enctype="multipart/form-data">
                <?php
                // Nonce field for security check
                wp_nonce_field('save_slider', 'save_slider_nonce');
                ?>
                <!-- Slider Name Input -->
                <div class="mb-3 mt-3">
                    <label for="slider_name" class="form-label">Slider Name:</label>
                    <input type="text" name="slider_name" id="slider_name" class="form-control" required>
                </div>

                <!-- Media Library Image Selector -->
                <h3>Select Images from Media Library:</h3>
                <div id="image-container" class="mb-3 mt-4">
                    <label for="image_upload" class="form-label">Upload Image:</label>
                    <!-- Hidden input field to store the selected image ID -->
                    <input type="hidden" name="selected_image_id" id="selected_image_id" value="">
                    <button id="select-images-button" class="button button-primary">Select Images</button>
                </div>

                <!-- Display selected images -->
                <div id="selected_images"></div>

                <!-- Submit Button -->
                <p class="submit">
                    <input type="hidden" name="action" value="save_slider">
                    <input type="submit" name="submit_slider" class="btn btn-success" value="Create Slider">
                </p>
            </form>
        </div>

        <?php
        // Check if sliders exist
        if (!empty($sliders)) {
            echo '<div class="container">';
            // Added FontAwesome icon
            echo '<h3 class="slider-toggle"><i class="fas fa-chevron-down"></i> Existing Sliders</h3>'; 

            // Initially hide the content
            echo '<div class="slider-content" style="display: none;">'; 
            foreach ($sliders as $slider) {
                $shortcode = '[slider id="' . esc_attr($slider['id']) . '"]';
                echo '<div class="card mb-3 mt-3  shadow">';
                echo '<div class="card-body">';
                echo "<strong>" . esc_attr($slider['id']) . "</strong>.";
                echo '<p class="card-text mt-1"><strong>Slider Name:</strong> ' . esc_html($slider['slider']) . '</p>';
                echo '<p class="card-text"><strong>Slider Shortcode:</strong> ' . esc_html($shortcode) . '</p>';
                echo '<p class="card-text">';
                echo '<a href="#" class="button button-primary mt-1" onclick="editSlider(' . esc_attr($slider['id']) . ')">Edit</a>.<br>';
                echo '<a href="#" class="button button-primary mt-2" onclick="deleteSlider(' . esc_attr($slider['id']) . ')">Delete</a>';

                echo '</p>';
                echo '</div>';
                echo '</div>';
            }
            echo '</div>';
            echo '</div>';
            wp_enqueue_script('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js', array(), '5.15.1', false);

            wp_enqueue_script('script', plugin_dir_url(__FILE__) . '../js/script.js', array('jquery'), '1.0', true);
           
        ?>
            <script>
                jQuery(document).ready(function($) {
                    $('.slider-toggle').click(function() {
                        $('.slider-content').slideToggle();
                    });

                });

                function deleteSlider(sliderId) {
                    var confirmation = confirm("Are you sure you want to delete this slider?");

                    if (confirmation) {
                        jQuery.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            data: {
                                action: 'delete_slider',
                                slider_id: sliderId,
                                security: '<?php echo wp_create_nonce("delete_slider_nonce"); ?>'
                            },
                            success: function(response) {
                                console.log(response);
                                var responseData = JSON.parse(response);

                                if (responseData.status === 'success') {
                                    // Handle success, e.g., remove the slider from the UI
                                    alert('Slider deleted successfully!');
                                } else {
                                    // Handle error, e.g., display an error message
                                    alert('Error deleting slider: ' + responseData.message);
                                }
                            },

                            error: function(error) {
                                console.error('AJAX error:', error);
                            }
                        });
                    }
                }
            </script>

        <?php

        } else {
            echo '<p>No sliders found.</p>';
        }

        ?>
    </div>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script>
        function editSlider(sliderId) {
            // Implement the logic to fetch slider data and redirect to edit page
            window.location.href = "<?php echo admin_url('admin.php?page=edit_slider&slider_id='); ?>" + sliderId;

        }
    </script>

<?php
}
