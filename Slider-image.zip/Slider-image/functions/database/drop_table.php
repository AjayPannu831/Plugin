<?php
function slider_image_drop_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'slider_images';
    $sql = "DROP TABLE IF EXISTS $table_name";
    $wpdb->query($sql);
}