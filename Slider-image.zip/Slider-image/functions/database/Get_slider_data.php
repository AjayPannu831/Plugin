<?php
function get_slider_data($slider_id)
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'slider_images';

    $slider_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $slider_id), ARRAY_A);

    return $slider_data;
}