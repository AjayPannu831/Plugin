<?php
function slider_image_create_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'slider_images';

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        `id` int(9) NOT NULL AUTO_INCREMENT,
        `slider` varchar(50) NOT NULL,
        `image` varchar(255) NOT NULL,
        `slider-show` INT(10) NOT NULL DEFAULT '1',
        `slider-scroll` INT(10) NOT NULL DEFAULT '1',
        `animation_type` VARCHAR(255) NOT NULL DEFAULT 'true',
        PRIMARY KEY  (id)
    );";

    $wpdb->query($sql);
}


