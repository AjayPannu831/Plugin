<?php
function delete_slider_callback()
{
    check_ajax_referer('delete_slider_nonce', 'security');

    if (isset($_POST['slider_id'])) {
        $slider_id = absint($_POST['slider_id']);

        global $wpdb;
        $table_name = $wpdb->prefix . 'slider_images';
        $sql = "DELETE FROM `$table_name` WHERE `id` = '$slider_id' ";
        $result = $wpdb->query($sql);

        if ($result !== false) {
            echo json_encode(['status' => 'success']);
        } else {
            error_log('Error deleting slider: ' . $wpdb->last_error);
            echo json_encode(['status' => 'error', 'message' => 'Error deleting slider. Please check the error log for details.']);
        }
    }

    wp_die();
}
