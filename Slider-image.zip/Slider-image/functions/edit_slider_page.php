<?php
function edit_slider_page()
{
?>
    <div>
        <div class="wrap container">
            <h3 class="text-center">Edit Slider</h3>
            <?php

            // Fetch the slider ID from the query parameters
            $slider_id = isset($_GET['slider_id']) ? absint($_GET['slider_id']) : 0;

            // Fetch slider data
            $slider_data = get_slider_data($slider_id);
            $existing_attachment_ids = isset($_POST['existing_attachment_ids']) ? explode(',', sanitize_text_field($_POST['existing_attachment_ids'])) : array();

            if ($slider_data) {
                // Display the slider data and provide the form for editing
                if (isset($_POST['submit_edit_slider']) && isset($_POST['slider_id'])) {
                    // Update slider data in the database
                    $updated_slider_name = sanitize_text_field($_POST['slider_name']);

                    // Ensure that 'existing_attachment_ids' is set in the $_POST array
                    $existing_attachment_ids = isset($_POST['existing_attachment_ids']) ? explode(',', sanitize_text_field($_POST['existing_attachment_ids'])) : array();

                    // Ensure that 'selected_attachment_ids' is set in the $_POST array
                    $new_image_ids = isset($_POST['selected_attachment_ids']) ? array_map('absint', $_POST['selected_attachment_ids']) : array();

                    // Get slides_to_show and slides_to_scroll from the form
                    $slides_to_show = isset($_POST['slides_to_show']) ? absint($_POST['slides_to_show']) : 1;
                    $slides_to_scroll = isset($_POST['slides_to_scroll']) ? absint($_POST['slides_to_scroll']) : 1;
                    $slider_height = isset($_POST['slider_height']) ? absint($_POST['slider_height']) : 400;

                    // Update database with the new slider information, image URLs, slide-show, and slide-scroll
                    update_slider_data($slider_id, $updated_slider_name, $new_image_ids, $slides_to_show, $slides_to_scroll, $slider_height);
                }
            ?>
                <form method="post" action="" id="edit-slider-form">
                    <input type="hidden" name="slider_id" value="<?php echo esc_attr($slider_id); ?>">

                    <!-- Display existing slider name -->
                    <h5 class="mt-4"> Slider Name:</h5>
                    <input type="text" name="slider_name" id="slider_name" value="<?php echo esc_attr($slider_data['slider']); ?>" required>

                    <!-- Display existing images with Lightbox functionality -->
                    <h5 class="mt-4">Edit Images:</h5>

                    <!-- Hidden input field to store existing image IDs -->

                    <div class="card">

                        <?php
                        // if ($slider_data['image']) {
                        ?>
                        <div id="image-container" class="card-body">
                            <?php
                            $images = explode(',', $slider_data['image']);
                            foreach ($images as $index => $image_url) {
                            ?>
                                <div class="image-item mt-3">
                                    <input type="checkbox" name="selected_images[]" class="select-image-checkbox" value="<?php echo esc_url($image_url); ?>">

                                    <img src="<?php echo esc_url($image_url); ?>" width="50%" height="100px" alt="Slider Image">
                                </div>
                            <?php
                            }
                            // }
                            ?>
                        </div>
                        <!-- Add a new button for deleting selected images -->
                        <button type="button" id="delete-selected-images" class="btn btn-danger mt-4 btn-sm">Delete Selected Images</button>

                    </div>

                    <!-- Hidden input field to store existing image IDs -->
                    <br>

                    <div class="form-group mt-4">
                        <label for="image_upload">Add More Images:</label>
                        <button id="select-images-button" class="button button-primary">Select Images</button>
                    </div>

                    <!-- Display selected images -->
                    <div id="selected_images" class="mt-4 mb-3"></div>
                    <div class="form-group mt-4 mb-4">
                        <label for="slider_height">Slider Height:</label>
                        <input type="number" name="slider_height" id="slider_height" value="<?php echo esc_attr($slider_data['Height_slider']); ?>" min="200" max="1000">
                    </div>

                    <?php
                    // Display input fields for slidesToShow and slidesToScroll
                    $slides_to_show = isset($_POST['slides_to_show']) ? absint($_POST['slides_to_show']) : 1;
                    $slides_to_scroll = isset($_POST['slides_to_scroll']) ? absint($_POST['slides_to_scroll']) : 1;
                    ?>

                    <!-- Display input fields for slidesToShow and slidesToScroll -->
                    <div class="form-group mt-4">
                        <label for="slides_to_show">Slides to Show:</label>
                        <input type="number" name="slides_to_show" id="slides_to_show" value="<?php echo esc_attr($slider_data['slider-show']); ?>" min="1">
                    </div>

                    <div class="form-group mt-4 mb-4">
                        <label for="slides_to_scroll">Slides to Scroll:</label>
                        <input type="number" name="slides_to_scroll" id="slides_to_scroll" value="<?php echo esc_attr($slider_data['slider-scroll']); ?>" min="1">
                    </div>

                    <div class="form-group mt-4 mb-4">
                        <label for="animation_type">Animation Type:</label>
                        <select name="animation_type" id="animation_type">
                            <option value="true" <?php echo ($slider_data['animation_type'] == 'true') ? 'selected' : ''; ?>>fade</option>
                            <option value="false" <?php echo ($slider_data['animation_type'] == 'false') ? 'selected' : ''; ?>>slide</option>
                            <!-- Add more options based on available animation types -->
                        </select>
                    </div>
                    <?php
                    $shortcode = '[slider id="' . esc_attr($slider_id) . '"]';
                    echo '<h5 class="card-text mt-4 mb-4"><strong>Slider Shortcode:</strong> ' . esc_html($shortcode) . '</h5>';
                    ?>

                    <div>
                        <h3 class="slider-toggle">&#9654; Preview Slider</h3>
                        <div class="slider-content" style="display: none;">

                            <?php
                            // Add FontAwesome CDN link in your plugin file or include it through your theme
                            wp_enqueue_script('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js', array(), '5.15.1', false);
                            wp_enqueue_script('script', plugin_dir_url(__FILE__) . '../js/script.js', array('jquery'), '1.0', true);
                            // Generate slider HTML based on the provided ID and parameters
                            global $wpdb;
                            $table_name = $wpdb->prefix . 'slider_images';

                            // Fetch slider images based on the provided ID
                            $slider_images = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE id = %s", $slider_id), ARRAY_A);

                            if (!empty($slider_images)) {
                                $slider_html = '<div class="container slick-slider">';
                                foreach ($slider_images as $slider_image) {
                                    $images = explode(',', $slider_image['image']);
                                    foreach ($images as $image_url) {
                                        $slider_html .= '<div class="image-container"><img src="' . esc_url($image_url) . '" alt="Slider Image" class="slider-image"></div>';
                                    }
                                }
                                $slider_html .= '</div>';
                                echo $slider_html;
                            }
                            ?>
                        </div>
                    </div>

                    <!-- Submit Button -->
                    <p class="submit">
                        <input type="hidden" name="action" value="edit_slider">
                        <button type="submit" name="submit_edit_slider" class="btn btn-primary"> Save Changes</button>
                    </p>
                </form>
                <script>
                    jQuery(document).ready(function($) {
                        // Select multiple images button click event
                        $('.slider-toggle').click(function() {
                            $('.slider-content').slideToggle();
                        });

                        // Delete selected images button click event
                        $('#delete-selected-images').on('click', function() {
                            var selectedImageUrls = $('.select-image-checkbox:checked').map(function() {
                                return $(this).val();
                            }).get();
                            // Send an AJAX request to delete the selected images on the server
                            $.ajax({
                                url: ajaxurl,
                                type: 'POST',
                                data: {
                                    action: 'handle_deleted_images',
                                    security: '<?php echo wp_create_nonce("handle_deleted_images_nonce"); ?>',
                                    image_urls: selectedImageUrls
                                },
                                success: function(response) {
                                    console.log(response);
                                    var responseData = JSON.parse(response);

                                    if (responseData.status === 'success') {
                                        // Handle success, e.g., display a success message
                                        alert('Selected images deleted successfully.');

                                        // Remove selected images from the UI
                                        $('.select-image-checkbox:checked').closest('.image-item').remove();

                                        // Additional actions if needed
                                    } else {
                                        // Handle error, e.g., display an error message
                                        alert('Error deleting selected images: ' + responseData.message);
                                    }
                                },
                                error: function(error) {
                                    console.error('AJAX error:', error);
                                }
                            });
                        });
                    });
                </script>
                <script>
                    jQuery(document).ready(function($) {
                        $('.slick-slider').slick({
                            slidesToShow: <?php echo esc_attr($slider_data['slider-show']); ?>,
                            slidesToScroll: <?php echo esc_attr($slider_data['slider-scroll']); ?>,
                            infinite: true,
                            dots: true,
                            arrows: true,
                            prevArrow: '<button type="button" class="slick-prev"></button>',
                            nextArrow: '<button type="button" class="slick-next"></button>',
                            autoplay: true,
                            autoplaySpeed: 1500,
                            fade: <?php echo ($slider_data['animation_type'] == 'true') ? 'true' : 'false'; ?>,
                        });
                    });
                </script>

                <style>
                    .slick-slider {
                        height: <?php echo esc_attr($slider_images['Height_slider']); ?>px;
                        width: 100%;
                        overflow: hidden;
                    }

                    .slider-image {
                        /* Make images cover the container without stretching */
                        width: 100%;
                        height: 100%;
                        object-fit: cover;
                        display: block;
                    }

                    .image-container {
                        /* Set the height and width you desire for each image container */
                        max-height: 100%;
                        max-width: 100%;
                        overflow: hidden;
                        margin: 10px;
                    }

                    .slick-prev,
                    .slick-next {
                        font-size: 24px;
                        line-height: 1;
                        color: #fff;
                        position: absolute;
                        top: 50%;
                        transform: translateY(-50%);
                        z-index: 1;
                    }

                    .slick-prev {
                        left: 10px;
                    }

                    .slick-next {
                        right: 25px;
                    }
                </style>

            <?php

            } else {
                // Slider not found, display an error message or redirect
                echo '<p class="text-danger">Slider not found.</p>';
            }
            ?>
        </div>
    </div>
<?php
}
