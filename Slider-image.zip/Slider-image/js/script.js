
    jQuery(document).ready(function ($) {
        $('#select-images-button').click(function (e) {
            e.preventDefault();

            var mediaUploader = wp.media({
                title: 'Select Images',
                button: {
                    text: 'Insert Selected Images'
                },
                multiple: true
            });

            mediaUploader.on('select', function () {
                var attachments = mediaUploader.state().get('selection').toJSON();
                var selectedImages = '';

                attachments.forEach(function (attachment) {
                    var filename = attachment.url.split('/').pop();
                    // selectedImages += '<div id="selected_images">';
                    selectedImages += '<img src="' + attachment.url + '" alt="Selected Image" style="max-width: 100px; margin-right: 10px;">';
                    // selectedImages += '</div>';
                    selectedImages += '<input type="hidden" name="selected_attachment_ids[]" value="' + attachment.id + '">';
                    
                });

                // Append selected images to the 'selected_images' div
                $('#selected_images').html(selectedImages);

               
            });

            mediaUploader.open();
        });
    });

