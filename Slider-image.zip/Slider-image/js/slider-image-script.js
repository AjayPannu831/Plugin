jQuery(document).ready(function ($) {
    $('#upload_images_button').on('click', function (e) {
        e.preventDefault();

        var frame = wp.media({
            title: 'Select Images',
            multiple: true,
            library: { type: 'image' },
            button: { text: 'Insert' }
        });

        frame.on('select', function () {
            var selection = frame.state().get('selection');
            var imageUrls = [];

            selection.each(function (attachment) {
                imageUrls.push(attachment.attributes.url);
            });

            // Display selected images (you can customize this part)
            console.log('Selected Images:', imageUrls);
        });

        frame.open();
    });
});
