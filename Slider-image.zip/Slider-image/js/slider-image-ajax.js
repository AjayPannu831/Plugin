jQuery(document).ready(function ($) {
    $('#upload_images_button').on('click', function (e) {
        e.preventDefault();
        openMediaUploader();
    });

    function openMediaUploader() {
        var mediaUploader = wp.media({
            title: 'Select Images',
            multiple: true,
            library: { type: 'image' },
            button: { text: 'Insert' },
        });

        mediaUploader.on('select', function () {
            var selection = mediaUploader.state().get('selection');
            var imageUrls = [];

            selection.each(function (attachment) {
                imageUrls.push(attachment.attributes.url);
            });

            // Display selected images
            displaySelectedImages(imageUrls);
        });

        mediaUploader.open();
    }

    function displaySelectedImages(imageUrls) {
        var imageContainer = $('#selected_images');
        imageContainer.empty();

        // Loop through selected images and display them
        imageUrls.forEach(function (imageUrl) {
            imageContainer.append('<img src="' + imageUrl + '" alt="Slider Image">');
        });

        // Save the selected images to a hidden input field (you can send this data to the server via AJAX)
        $('#slider_images_input').val(JSON.stringify(imageUrls));
    }
});
