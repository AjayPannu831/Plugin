jQuery(document).ready(function($) {
                    $('.slider-toggle').click(function() {
                        $('.slider-content').slideToggle();
                    });

                });

                function deleteSlider(sliderId) {
                    var confirmation = confirm("Are you sure you want to delete this slider?");

                    if (confirmation) {
                        jQuery.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            data: {
                                action: 'delete_slider',
                                slider_id: sliderId,
                                security: '<?php echo wp_create_nonce("delete_slider_nonce"); ?>'
                            },
                            success: function(response) {
                                console.log(response);
                                if (response === 'success') {
                                    // Handle success, e.g., remove the slider from the UI
                                    alert('Slider deleted successfully!');
                                } else {
                                    // Handle error, e.g., display an error message
                                    alert('Error deleting slider: ' + response);
                                }
                            },
                            error: function(error) {
                                console.error('AJAX error:', error);
                            }
                        });
                    }
                }