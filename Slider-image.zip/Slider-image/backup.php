<?php

/**
 * Plugin Name: Slider-Image
 * Description: This is a demo of the slider that shows how to make a plugin and its use.
 * Version: 1
 * Require PHP: 7.0
 * Author: Ajay Pannu
 * Author URI: https://ajaypannu003.000webhostapp.com
 */

if (!defined('ABSPATH')) {
    exit;
}
function enqueue_plugin_scripts()
{
    // Bootstrap cdn link
    wp_enqueue_style('Bootstrap-style', 'https://maxcdn.bootstrapcdn.com/bootstrap/5.3.2/css/bootstrap.min.css');
    wp_enqueue_script('Bootstrap-js', 'https://maxcdn.bootstrapcdn.com/bootstrap/5.3.2/js/bootstrap.bundle.min.js', array('jquery'), '5.3.2', true);


    // Enqueue Slick slider CSS
    wp_enqueue_style('slick-style', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css');
    wp_enqueue_style('slick-theme-style', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css');

    // Enqueue Slick slider JS
    wp_enqueue_script('slick-script', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js', array('jquery'), '1.8.1', true);

    // Enqueue your initialization script
    wp_enqueue_script('slick-init', plugins_url('your-script.js', __FILE__), array('jquery', 'slick-script'), '1.0', true);
}

add_action('wp_enqueue_scripts', 'enqueue_plugin_scripts');



// Enqueue script to handle media library integration
function enqueue_media_script()
{
    wp_enqueue_media();
    wp_enqueue_script('slider-image-script', plugins_url('/js/script.js', __FILE__), array('jquery'), null, true);
    // Enqueue Lightbox CSS and JS
    wp_enqueue_style('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css', array(), null, 'all');
    wp_enqueue_script('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js', array('jquery'), null, true);

    // Enqueue Slick slider CSS and JS
    wp_enqueue_style('slick-carousel', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css', array(), null, 'all');
    wp_enqueue_style('slick-carousel-theme', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css', array(), null, 'all');
    wp_enqueue_script('slick-carousel', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js', array('jquery'), null, true);
    // Localize script with AJAX URL
    // wp_enqueue_script('slick-init', plugins_url('your-script.js', __FILE__), array('jquery', 'slick-script'), '1.0', true);

    // // Localize script with AJAX URL
    // wp_localize_script('slick-init', 'ajax_object', array('ajaxurl' => admin_url('admin-ajax.php'), 'security' => wp_create_nonce('delete_slider_nonce')));
    //     wp_enqueue_script('your-script-handle', 'path-to-your-script.js', array('jquery'), null, true);

    // // Localize the script with AJAX URL and nonce
    // wp_localize_script('your-script-handle', 'your_ajax_obj', array(
    //     'ajaxurl' => admin_url('your-script.js'),
    //     'nonce' => wp_create_nonce('delete_image_nonce')
    // ));
}
add_action('admin_enqueue_scripts', 'enqueue_media_script');
// Activation hook to create the database table
register_activation_hook(__FILE__, 'slider_image_create_table');

// Deactivation hook to drop the database table
// register_deactivation_hook(__FILE__, 'slider_image_drop_table');


// Add menu item to the dashboard
add_action('admin_menu', 'slider_image_menu');

// Callback function to create the database table
function slider_image_create_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'slider_images';

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        `id` int(9) NOT NULL AUTO_INCREMENT,
        `slider` varchar(50) NOT NULL,
        `image` varchar(255) NOT NULL,
        `slider-show` INT(10) NOT NULL DEFAULT '1',
        `slider-scroll` INT(10) NOT NULL DEFAULT '1',
        PRIMARY KEY  (id)
    );";

    $wpdb->query($sql);
}

// Callback function to drop the database table on deactivation
function slider_image_drop_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'slider_images';
    $sql = "DROP TABLE IF EXISTS $table_name";
    $wpdb->query($sql);
}

// Callback function for the menu page
function slider_image_menu()
{
    add_menu_page(
        'Slider Image Settings',
        'Slider Image',
        'manage_options',
        'slider_image_settings',
        'slider_image_page'
    );
    add_submenu_page(
        'slider_image_settings',
        'Edit Slider',
        'Edit Slider',
        'manage_options',
        'edit_slider',
        'edit_slider_page'
    );
}

// Callback function to display the page content
function slider_image_page()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'slider_images';

    // Check if the form is submitted
    if (isset($_POST['submit_slider']) && isset($_POST['slider_name'])) {
        // Check if any image is selected
        if (isset($_POST['selected_attachment_ids']) && !empty($_POST['selected_attachment_ids'])) {
            // Verify nonce
            if (isset($_POST['save_slider_nonce']) && wp_verify_nonce($_POST['save_slider_nonce'], 'save_slider')) {
                $slider_name = sanitize_text_field($_POST['slider_name']);
                $attachment_ids = array_map('absint', $_POST['selected_attachment_ids']);
                $image_names = array();

                // Insert data into the table
                foreach ($attachment_ids as $attachment_id) {
                    $image_names[] = wp_get_attachment_url($attachment_id);
                }

                $result = $wpdb->insert(
                    $table_name,
                    array(
                        'slider' => $slider_name,
                        'image' => implode(',', $image_names),
                    )
                );
                if ($result == true) {
                    // Display success message
                    echo '<div class="updated"><p>Slider created successfully!</p></div>';
                } else {
                    // Display error message if the insert failed
                    echo '<div class="error"><p>Error creating slider. Please try again.</p></div>';
                }
            }
        } else {
            echo '<div class="error"><p>Error creating slider. Please select image at least 1.</p></div>';
        }
    }
    // Fetch all sliders from the database
    $sliders = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);
?>

    <div class="wrap container">
        <div class="container">
            <h2>Create Slider</h2>
            <form method="post" action="" enctype="multipart/form-data">
                <?php
                // Nonce field for security check
                wp_nonce_field('save_slider', 'save_slider_nonce');
                ?>
                <!-- Slider Name Input -->
                <div class="mb-3 mt-3">
                    <label for="slider_name" class="form-label">Slider Name:</label>
                    <input type="text" name="slider_name" id="slider_name" class="form-control" required>
                </div>

                <!-- Media Library Image Selector -->
                <h3>Select Images from Media Library:</h3>
                <div id="image-container" class="mb-3 mt-4">
                    <label for="image_upload" class="form-label">Upload Image:</label>
                    <!-- Hidden input field to store the selected image ID -->
                    <input type="hidden" name="selected_image_id" id="selected_image_id" value="">
                    <button id="select-images-button" class="button button-primary">Select Images</button>
                </div>

                <!-- Display selected images -->
                <div id="selected_images"></div>

                <!-- Submit Button -->
                <p class="submit">
                    <input type="hidden" name="action" value="save_slider">
                    <input type="submit" name="submit_slider" class="btn btn-success" value="Create Slider">
                </p>
            </form>
        </div>

        <?php
        // Check if sliders exist
        if (!empty($sliders)) {
            echo '<div class="container">';
            echo '<h3 class="slider-toggle"><i class="fas fa-chevron-down"></i> Existing Sliders</h3>'; // Added FontAwesome icon
            echo '<div class="slider-content" style="display: none;">'; // Initially hide the content
            foreach ($sliders as $slider) {
                $shortcode = '[slider id="' . esc_attr($slider['id']) . '"]';
                echo '<div class="card mb-3 mt-3  shadow">';
                echo '<div class="card-body">';
                echo "<strong>" . esc_attr($slider['id']) . "</strong>.";
                echo '<p class="card-text mt-1"><strong>Slider Name:</strong> ' . esc_html($slider['slider']) . '</p>';
                echo '<p class="card-text"><strong>Slider Shortcode:</strong> ' . esc_html($shortcode) . '</p>';
                echo '<p class="card-text">';
                echo '<a href="#" class="button button-primary mt-1" onclick="editSlider(' . esc_attr($slider['id']) . ')">Edit</a>.<br>';
                echo '<a href="#" class="button button-primary mt-2" onclick="deleteSlider(' . esc_attr($slider['id']) . ')">Delete</a>';

                echo '</p>';
                echo '</div>';
                echo '</div>';
            }
            echo '</div>';
            echo '</div>';

            // Add FontAwesome CDN link in your plugin file or include it through your theme
            wp_enqueue_script('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js', array(), '5.15.1', false);
        ?>
            <script>
                // Define deleteSlider function in the global scope


                jQuery(document).ready(function($) {
                    $('.slider-toggle').click(function() {
                        $('.slider-content').slideToggle();
                    });

                });

                function deleteSlider(sliderId) {
                    var confirmation = confirm("Are you sure you want to delete this slider?");

                    if (confirmation) {
                        jQuery.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            data: {
                                action: 'delete_slider',
                                slider_id: sliderId,
                                security: '<?php echo wp_create_nonce("delete_slider_nonce"); ?>'
                            },
                            success: function(response) {
                                console.log(response);
                                var responseData = JSON.parse(response);

                                if (responseData.status === 'success') {
                                    // Handle success, e.g., remove the slider from the UI
                                    alert('Slider deleted successfully!');
                                } else {
                                    // Handle error, e.g., display an error message
                                    alert('Error deleting slider: ' + responseData.message);
                                }
                            },

                            error: function(error) {
                                console.error('AJAX error:', error);
                            }
                        });
                    }
                }
            </script>
        <?php
        } else {
            echo '<p>No sliders found.</p>';
        }
        ?>
    </div>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script>
        function editSlider(sliderId) {
            window.location.href = "<?php echo admin_url('admin.php?page=edit_slider&slider_id='); ?>" + sliderId;
        }
    </script>
<?php
}
// Add this action to handle slider deletion
add_action('wp_ajax_delete_slider', 'delete_slider_callback');
function delete_slider_callback()
{
    check_ajax_referer('delete_slider_nonce', 'security');

    if (isset($_POST['slider_id'])) {
        $slider_id = absint($_POST['slider_id']);

        global $wpdb;
        $table_name = $wpdb->prefix . 'slider_images';
        $sql = "DELETE FROM `$table_name` WHERE `id` = '$slider_id' ";
        $result = $wpdb->query($sql);

        if ($result !== false) {
            echo json_encode(['status' => 'success']);
        } else {
            error_log('Error deleting slider: ' . $wpdb->last_error);
            echo json_encode(['status' => 'error', 'message' => 'Error deleting slider. Please check the error log for details.']);
        }
    }

    wp_die();
}
function generate_slider_html($slider_id)
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'slider_images';

    // Fetch slider images based on the provided ID
    $slider_images = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE id = %s", $slider_id), ARRAY_A);

    if (!empty($slider_images)) {
        $slider_html = '<div class="container slick-slider">';
        foreach ($slider_images as $slider_image) {
            $images = explode(',', $slider_image['image']);
            foreach ($images as $image_url) {
                $slider_html .= '<img src="' . esc_url($image_url) . '"  alt="Slider Image">';
            }
        }
        $slider_html .= '</div>';

        return $slider_html;
    }

    // Return empty string if no images found
    return '';
}


// Register the shortcode
add_shortcode('slider', 'slider_shortcode');


function slider_shortcode($atts)
{
    // Extract shortcode attributes
    $atts = shortcode_atts(
        array(
            'id' => '', // Default value for the slider ID
        ),
        $atts,
        'slider'
    );

    // Fetch slider data
    $slider_data = get_slider_data($atts['id']);

    // Generate slider HTML based on the provided ID
    $slider_html = generate_slider_html($atts['id']);

    // Output the slider HTML
    echo $slider_html;

    // Output the JavaScript script with dynamic values
?>
    <script>
        jQuery(document).ready(function($) {
            // Initialize slick slider
            $('.slick-slider').slick({
                slidesToShow: <?php echo esc_attr($slider_data['slider-show']); ?>,
                slidesToScroll: <?php echo esc_attr($slider_data['slider-scroll']) ?>,
                infinite: true,
                dots: true,
                autoplay: true,
                autoplaySpeed: 500,
            });
        });
    </script>
<?php
}


// Add this function to fetch slider data
function get_slider_data($slider_id)
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'slider_images';

    $slider_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $slider_id), ARRAY_A);

    return $slider_data;
}

// Callback function for the edit slider page

function edit_slider_page()
{
?>
    <div>
        <div class="wrap container">
            <h3 class="text-center">Edit Slider</h3>
            <?php

            // Fetch the slider ID from the query parameters
            $slider_id = isset($_GET['slider_id']) ? absint($_GET['slider_id']) : 0;

            // Fetch slider data
            $slider_data = get_slider_data($slider_id);
            $existing_attachment_ids = isset($_POST['existing_attachment_ids']) ? explode(',', sanitize_text_field($_POST['existing_attachment_ids'])) : array();

            if ($slider_data) {
                // Display the slider data and provide the form for editing
            ?>
                <form method="post" action="">
                    <input type="hidden" name="slider_id" value="<?php echo esc_attr($slider_id); ?>">

                    <!-- Display existing slider name -->
                    <h5 class="mt-4"> Slider Name:</h5>
                    <input type="text" name="slider_name" id="slider_name" value="<?php echo esc_attr($slider_data['slider']); ?>" required>

                    <!-- Display existing images with Lightbox functionality -->
                    <h5 class="mt-4">Edit Images:</h5>

                    <!-- Hidden input field to store existing image IDs -->
                    <input type="hidden" name="existing_attachment_ids" id="existing_attachment_ids" value="<?php echo esc_attr($slider_data['image']); ?>">
                    <div class="card">
                        <div id="image-container" class="card-body">
                            <?php
                            $images = explode(',', $slider_data['image']);
                            foreach ($images as $image_url) {
                            ?>
                                <div class="image-item mt-3">
                                    <img src="<?php echo esc_url($image_url); ?>" width="25%" alt="Slider Image">
                                    <a href="#" class="btn btn-danger delete-image" data-image-url="<?php echo esc_url($image_url); ?>">Delete</a>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                    </div>

                    <!-- Hidden input field to store existing image IDs -->
                    <input type="hidden" name="existing_attachment_ids" id="existing_attachment_ids" value="<?php echo esc_attr($slider_data['image']); ?>"><br>

                    <div class="form-group mt-4">
                        <label for="image_upload">Add More Images:</label>
                        <button id="select-images-button" class="button button-primary">Select Images</button>
                    </div>

                    <!-- Display selected images -->
                    <div id="selected_images" class="mt-4 mb-3"></div>

                    <?php
                    // Display input fields for slidesToShow and slidesToScroll
                    $slides_to_show = isset($_POST['slides_to_show']) ? absint($_POST['slides_to_show']) : 1;
                    $slides_to_scroll = isset($_POST['slides_to_scroll']) ? absint($_POST['slides_to_scroll']) : 1;
                    ?>

                    <!-- Display input fields for slidesToShow and slidesToScroll -->
                    <div class="form-group mt-4">
                        <label for="slides_to_show">Slides to Show:</label>
                        <input type="number" name="slides_to_show" id="slides_to_show" value="<?php echo esc_attr($slider_data['slider-show']); ?>" min="1">
                    </div>

                    <div class="form-group mt-4 mb-4">
                        <label for="slides_to_scroll">Slides to Scroll:</label>
                        <input type="number" name="slides_to_scroll" id="slides_to_scroll" value="<?php echo esc_attr($slider_data['slider-scroll']); ?>" min="1">
                    </div>

                    <?php
                    // Generate slider HTML based on the provided ID and parameters
                    global $wpdb;
                    $table_name = $wpdb->prefix . 'slider_images';

                    // Fetch slider images based on the provided ID
                    $slider_images = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE id = %s", $slider_id), ARRAY_A);

                    if (!empty($slider_images)) {
                        $slider_html = '<div class="container slick-slider">';
                        foreach ($slider_images as $slider_image) {
                            $images = explode(',', $slider_image['image']);
                            foreach ($images as $image_url) {
                                $slider_html .= '<img src="' . esc_url($image_url) . '"  alt="Slider Image">';
                            }
                        }
                        $slider_html .= '</div>';
                        echo $slider_html;
                    }

                    $shortcode = '[slider id="' . esc_attr($slider_id) . '"]';
                    echo '<h3 class="card-text"><strong>Slider Shortcode:</strong> ' . esc_html($shortcode) . '</h3>';
                    ?>

                    <!-- Submit Button -->
                    <p class="submit">
                        <input type="hidden" name="action" value="edit_slider">
                        <button type="submit" name="submit_edit_slider" class="btn btn-primary"> Save Changes</button>
                    </p>
                </form>
                <!-- // Slick slider initialization script -->
                <script>
                    jQuery(document).ready(function($) {
                        // Initialize slick slider
                        $('.slick-slider').slick({
                            slidesToShow: <?php echo esc_attr($slider_data['slider-show']); ?>,
                            slidesToScroll: <?php echo esc_attr($slider_data['slider-scroll']); ?>,
                            infinite: true,
                            dots: true,
                            autoplay: true,
                            autoplaySpeed: 500
                        });

                        // Attach click event to delete buttons
                        $('.delete-image').on('click', function(e) {
                            e.preventDefault();

                            // Get the image URL from the data attribute
                            var imageUrl = $(this).data('image-url');

                            // Remove the image item from the DOM
                            var imageItem = $(this).closest('.image-item');
                            imageItem.remove();

                            // Add the image URL to a hidden input field for server-side processing
                            var existingImageIdsInput = $('#existing_attachment_ids');
                            var existingImageIds = existingImageIdsInput.val().split(',');
                            var indexToRemove = existingImageIds.indexOf(imageUrl);
                            if (indexToRemove !== -1) {
                                existingImageIds.splice(indexToRemove, 1);
                                existingImageIdsInput.val(existingImageIds.join(','));

                                // Log the updated value to the console
                                console.log('Updated Existing Attachment IDs:', existingImageIdsInput.val());

                            }
                        });
                    });
                </script>


            <?php
                function handle_deleted_images($image_urls)
                {
                    $deleted_images = array();

                    global $wpdb;
                    $table_name = $wpdb->prefix . 'slider_images';

                    if (!is_array($image_urls)) {
                        $image_urls = array();
                    }

                    foreach ($image_urls as $image_url) {
                        $deleted = $wpdb->delete($table_name, array('image' => $image_url), array('%s'));

                        if ($deleted === false) {
                            // Check for errors in the delete operation
                            $wpdb_last_error = $wpdb->last_error;
                            error_log('Error deleting image: ' . $wpdb_last_error);
                        } else {
                            $deleted_images[] = $image_url;
                            error_log('Image deleted successfully: ' . $image_url);
                        }
                    }

                    error_log('Deleted Images: ' . print_r($deleted_images, true));

                    // return $deleted_images;
                }

                // Handle form submission for editing the slider
                if (isset($_POST['submit_edit_slider']) && isset($_POST['slider_id'])) {
                    // Update slider data in the database
                    $updated_slider_name = sanitize_text_field($_POST['slider_name']);

                    // Ensure that 'existing_attachment_ids' is set in the $_POST array
                    $existing_attachment_ids = isset($_POST['existing_attachment_ids']) ? explode(',', sanitize_text_field($_POST['existing_attachment_ids'])) : array();

                    // Ensure that 'selected_attachment_ids' is set in the $_POST array
                    $new_image_ids = isset($_POST['selected_attachment_ids']) ? array_map('absint', $_POST['selected_attachment_ids']) : array();

                    // Get slides_to_show and slides_to_scroll from the form
                    $slides_to_show = isset($_POST['slides_to_show']) ? absint($_POST['slides_to_show']) : 1;
                    $slides_to_scroll = isset($_POST['slides_to_scroll']) ? absint($_POST['slides_to_scroll']) : 1;

                    handle_deleted_images($existing_attachment_ids);
                    // Update database with the new slider information, image URLs, slide-show, and slide-scroll
                    update_slider_data($slider_id, $updated_slider_name, $new_image_ids, $slides_to_show, $slides_to_scroll);

                    // Output success or error message based on the result of the update
                    // echo '<p class="text-success">Slider updated.</p>';
                }
            } else {
                // Slider not found, display an error message or redirect
                echo '<p class="text-danger">Slider not found.</p>';
            }
            ?>
        </div>
    </div>
<?php
}



// Function to update slider data in the database
function update_slider_data($slider_id, $slider_name, $new_image_ids, $slides_to_show, $slides_to_scroll)
{
    global $wpdb;

    // Define the table name
    $table_name = $wpdb->prefix . 'slider_images';

    // Fetch existing image URLs
    $existing_image_urls = $wpdb->get_var($wpdb->prepare("SELECT image FROM $table_name WHERE id = %d", $slider_id));

    // Fetch new image URLs based on new image IDs
    $new_image_urls = array_map('wp_get_attachment_url', $new_image_ids);

    // Combine existing and new image URLs
    $all_image_urls = implode(',', array_filter(array_merge(explode(',', $existing_image_urls), $new_image_urls)));

    // Update slider name, images, slide-show, and slide-scroll
    $result = $wpdb->update(
        $table_name,
        array(
            'slider' => $slider_name,
            'image' => $all_image_urls,
            'slider-show' => $slides_to_show,
            'slider-scroll' => $slides_to_scroll
        ),
        array('id' => $slider_id),
        array('%s', '%s', '%d', '%d'), // Data Format for slider name, image, slide-show, and slide-scroll
        array('%d')                      // Where Format
    );

    if ($result !== false) {
        echo '<p class="text-success">Slider updated successfully!</p>';
    } else {
        echo '<p class="text-danger">Failed to update slider.</p>';
    }
}


// Function to get slider images from the database
function get_slider_images()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'slider_images';
    $result = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);
    return $result;
}

function shortcode()
{
    // Fetch and display images in the slick slider
    $slider_images = get_slider_images();

    if (!empty($slider_images)) {
        echo '<div class="slider">';
        foreach ($slider_images as $slider_image) {
            $images = explode(',', $slider_image['image']);
            foreach ($images as $image_url) {
                echo '<img src="' . $image_url . '" width="50%" height="400px" alt="Slider Image">';
            }
        }
        echo '</div>';
    }
?>

    <script>
        jQuery(document).ready(function($) {
            // Initialize slick slider
            $('.slider').slick({
                // Adjust the number of slides to show
                slidesToShow: 1,
                slidesToScroll: 1,
                infinite: true,
                dots: true,
                autoplay: true,
                autoplaySpeed: 500,
            });
        });
    </script>

<?php
}
add_shortcode('image-slider', 'shortcode');
